package com.yitaihuang.ticketrush.reservation;

import java.time.Duration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * Turns every Redis restart or failover into a full loss, the one Redis failure
 * the recovery is built for.
 *
 * <p>A Redis that comes back from an AOF or RDB file, or a replica promoted after
 * the primary died, holds an older copy of the events' state: the orders,
 * tickets and idempotency keys of its last second (or hours) are missing, but
 * the stock key is there, so nothing else would notice and it would keep selling
 * on that state. No timestamp tells such an order apart from one whose request
 * paused before its send, so instead every second this compares the server's
 * run_id (new after each restart, different on another server) with the one
 * recorded in Redis itself. On a mismatch one instance deletes every event's
 * keys, stock first, so reservations stop at once ({@code 503 STOCK_RECOVERING}),
 * and the fenced rebuild recreates them from MySQL. A missing record (a fresh or
 * emptied Redis) counts as a mismatch.
 *
 * <p>Until the check runs, up to about a second after the restart, reservations
 * still run on the old state; compose runs Redis without persistence so that a
 * restart comes back empty and is refused at once.
 */
@Component
public class RedisRestartGuard {

	private static final Logger log = LoggerFactory.getLogger(RedisRestartGuard.class);

	/** The run_id of the server whose state the app last trusted. */
	public static final String SERVER_KEY = "ticketrush:redis-server";

	private static final String WIPE_LOCK = "ticketrush:redis-server:wiping";

	/** Long enough to wipe every event; if the wiper dies, the next check after it redoes the wipe. */
	private static final Duration WIPE_LEASE = Duration.ofMinutes(1);

	private final StockGateway stock;

	private final StringRedisTemplate redis;

	private final Counter detected;

	public RedisRestartGuard(StockGateway stock, StringRedisTemplate redis, MeterRegistry meters) {
		this.stock = stock;
		this.redis = redis;
		this.detected = meters.counter("ticketrush.redis.restarts_detected");
	}

	@Scheduled(fixedDelayString = "${ticketrush.reservations.redis-check-interval:PT1S}")
	public void run() {
		try {
			check();
		}
		catch (RuntimeException ex) {
			log.warn("Could not check the Redis server: {}", ex.toString());
		}
	}

	public void check() {
		String server = stock.serverRunId();
		if (server.equals(redis.opsForValue().get(SERVER_KEY))) {
			return;
		}
		if (!Boolean.TRUE.equals(redis.opsForValue().setIfAbsent(WIPE_LOCK, server, WIPE_LEASE))) {
			return; // another instance is wiping
		}
		detected.increment();
		int deleted = stock.wipeAllEvents();
		redis.opsForValue().set(SERVER_KEY, server);
		redis.delete(WIPE_LOCK);
		log.error("Redis server changed (now {}): its event state may be old, deleted {} keys to rebuild from MySQL",
				server, deleted);
	}

}
